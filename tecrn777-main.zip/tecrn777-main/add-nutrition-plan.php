<?php
session_start();

// Only Coach can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coach') {
    header("Location: signin.php");
    exit();
}

$athleteName = $_GET['athlete'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Nutrition Plan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2>Assign Nutrition Plan <?php echo $athleteName ? "to " . htmlspecialchars($athleteName) : ""; ?></h2>
    <form method="POST" action="save-nutrition-plan.php">
        <div class="mb-3">
            <label for="planName" class="form-label">Nutrition Plan Name</label>
            <input type="text" class="form-control" id="planName" name="plan_name" required>
        </div>
        <div class="mb-3">
            <label for="planDetails" class="form-label">Details</label>
            <textarea class="form-control" id="planDetails" name="plan_details" rows="5" required></textarea>
        </div>
        <input type="hidden" name="athlete" value="<?php echo htmlspecialchars($athleteName); ?>">
        <button type="submit" class="btn btn-success">Assign Plan</button>
        <a href="coach-dashboard.php" class="btn btn-secondary">Back</a>
    </form>
</div>
</body>
</html>
