<?php
session_start();
header('Content-Type: application/json');

// Optional: restrict to athletes
// if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Athlete') {
//     echo json_encode(['reply' => 'Unauthorized']);
//     exit;
// }

$question = $_POST['question'] ?? '';
if (!$question) {
    echo json_encode(['reply' => 'Please ask a question.']);
    exit;
}

$apiKey = 'YOUR_OPENAI_API_KEY'; // Replace with your real API key

$ch = curl_init('https://api.openai.com/v1/chat/completions');
$data = [
    "model" => "gpt-3.5-turbo", // or gpt-4-mini if allowed
    "messages" => [
        ["role" => "system", "content" => "You are a helpful AI coach assistant for athletes."],
        ["role" => "user", "content" => $question]
    ]
];

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
if(curl_errno($ch)){
    echo json_encode(['reply' => 'Error: '.curl_error($ch)]);
    exit;
}
curl_close($ch);

$responseData = json_decode($response, true);
$reply = $responseData['choices'][0]['message']['content'] ?? 'Sorry, I could not respond.';
echo json_encode(['reply' => $reply]);
