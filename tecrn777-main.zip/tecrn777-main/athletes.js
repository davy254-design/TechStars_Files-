const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const {getAllAthletes} = require('../middleware/authMiddleware');

//Protect this route with auth middleware
router.get('/athletes', auth, getAllAthletes);

module.exports = router;