<?php
$servername = "localhost";
$username = "root";      // default XAMPP username
$password = "";          // leave blank unless you set one
$dbname = "athlete";     // your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
