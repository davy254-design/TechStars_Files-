<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coach') {
    header("Location: signin.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'athlete'); // your DB name
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$athleteName = $_POST['athlete'] ?? '';
$planName = $_POST['plan_name'] ?? '';
$planDetails = $_POST['plan_details'] ?? '';
$coachId = $_SESSION['id'] ?? 0; // assuming session has coach id

if ($athleteName && $planName && $planDetails) {
    // Get athlete ID from users table
    $stmt = $conn->prepare("SELECT id FROM users WHERE fullname = ? AND role = 'Athlete'");
    $stmt->bind_param("s", $athleteName);
    $stmt->execute();
    $stmt->bind_result($athleteId);
    $stmt->fetch();
    $stmt->close();

    if ($athleteId) {
        $stmt = $conn->prepare("INSERT INTO training_plans (athlete_id, coach_id, plan_name, plan_details) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $athleteId, $coachId, $planName, $planDetails);
        if ($stmt->execute()) {
            header("Location: coach-dashboard.php?success=1");
            exit();
        } else {
            echo "Error saving plan: " . $stmt->error;
        }
    } else {
        echo "Athlete not found.";
    }
}
?>
