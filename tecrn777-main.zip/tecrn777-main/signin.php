<?php
session_start();
header('Content-Type: application/json');

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "athlete"; // ✅ Change to your actual DB name

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed."]);
    exit();
}

// Receive form data
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($email) || empty($password)) {
    echo json_encode(["status" => "error", "message" => "Please enter both email and password."]);
    exit();
}

// Check user
$stmt = $conn->prepare("SELECT id, fullname, email, password, role FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // Verify password
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];

        // ✅ Redirect based on role
        switch ($user['role']) {
            case 'Athlete':
                $redirect = 'athlete-dashboard.html';
                break;
            case 'Coach':
                $redirect = 'coach-dashboard.php';
                break;
            case 'Admin':
                $redirect = 'admin-dashboard.php';
                break;
            case 'Nutritionist':
                $redirect = 'nutritionist-dashboard.html';
                break;
            default:
                $redirect = 'dashboard.html';
        }

        echo json_encode(["status" => "success", "redirect" => $redirect]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid password."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "No account found with that email."]);
}

$stmt->close();
$conn->close();
?>
