<?php
session_start();

// Only Coach can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coach') {
    header("Location: signin.php");
    exit();
}

// Fetch coach name
$coachName = $_SESSION['fullname'] ?? 'Coach';

// Connect to the database
$host = "localhost";
$user = "root";
$pass = ""; // replace if you have a password
$db   = "athlete"; // your database name

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch athletes assigned to this coach (replace with real assignment logic if needed)
$sql = "SELECT id, fullname, weekly_load, chronic_ratio FROM users WHERE role='Athlete'";
$result = $conn->query($sql);

$athletes = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $athletes[] = [
            'id' => $row['id'],
            'name' => $row['fullname'],
            'weekly_load' => $row['weekly_load'] ?? 'N/A',
            'ac_ratio' => $row['chronic_ratio'] ?? 'N/A'
        ];
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coach Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container-fluid">
    <nav class="navbar navbar-dark bg-primary mb-4">
        <div class="container d-flex justify-content-between">
            <span class="navbar-brand mb-0 h1">Coach Dashboard</span>
            <div class="d-flex align-items-center">
                <span class="text-white me-3">Welcome, <?php echo htmlspecialchars($coachName); ?></span>
                <a href="signin-page.html" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>

    <div class="row">
        <!-- Athlete Summary Section -->
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5><i class="fas fa-users"></i> My Athletes</h5>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Athlete Name</th>
                                <th>Weekly Load</th>
                                <th>Acute:Chronic Ratio</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($athletes)): ?>
                                <?php foreach($athletes as $athlete): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($athlete['name']); ?></td>
                                    <td><?php echo htmlspecialchars($athlete['weekly_load']); ?> </td>
                                    <td><?php echo htmlspecialchars($athlete['ac_ratio']); ?></td>
                                    <td>
                                        <a href="view-performance-metrics.php?athlete=<?php echo urlencode($athlete['id']); ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-chart-line"></i> View Metrics
                                        </a>
                                        <a href="add-new-plan.php?athlete=<?php echo urlencode($athlete['id']); ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i> Assign Plan
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4">No athletes found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <p class="text-muted"><small>Data is fetched live from the database.</small></p>
                </div>
            </div>
        </div>

        <!-- Training Plan Section -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fas fa-dumbbell"></i> Training Plans</h5>
                </div>
                <div class="card-body">
                    <p>Create or manage training plans for your athletes here.</p>
                    <a href="add-new-plan.php" class="btn btn-success"><i class="fas fa-plus"></i> Add New Plan</a>
                </div>
            </div>
        </div>

        <!-- Nutrition Plan Section -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5><i class="fas fa-utensils"></i> Nutrition Plans</h5>
                </div>
                <div class="card-body">
                    <p>Track or assign nutrition plans for your athletes.</p>
                    <a href="add-nutrition-plan.php" class="btn btn-success"><i class="fas fa-plus"></i> Assign Nutrition Plan</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
