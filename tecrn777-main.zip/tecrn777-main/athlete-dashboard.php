<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Athlete') {
    header("Location: signin.php");
    exit;
}

// Get athlete's name from session
$athleteName = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Athlete Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container-fluid">
    <nav class="navbar navbar-dark bg-primary mb-4">
        <div class="container">
            <span class="navbar-brand mb-0 h1">Athlete Dashboard</span>
            <span class="text-white">Welcome, <?php echo htmlspecialchars($athleteName); ?></span>
        </div>
    </nav>

    <div class="row">
        <!-- Training Load Section -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fas fa-dumbbell"></i> Training Load</h5>
                </div>
                <div class="card-body">
                    <canvas id="trainingLoadChart"></canvas>
                    <div class="mt-3">
                        <h6>Weekly Load: <span class="text-primary">2450 units</span></h6>
                        <h6>Acute:Chronic Ratio: <span class="text-success">1.1</span></h6>
                    </div>
                </div>
            </div>
        </div>

        <!-- Diet Tracking -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5><i class="fas fa-utensils"></i> Nutrition</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Daily Calories: 2800/3000</h6>
                            <div class="progress mb-3">
                                <div class="progress-bar" role="progressbar" style="width: 93%"></div>
                            </div>
                            <h6>Protein: 180g/200g</h6>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 90%"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6>Carbs: 300g/350g</h6>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 85%"></div>
                            </div>
                            <h6>Fats: 65g/70g</h6>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 92%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recovery Plans -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5><i class="fas fa-bed"></i> Recovery Status</h5>
                </div>
                <div class="card-body">
                    <h6>Sleep Quality: 8.5hrs <span class="badge bg-success">Good</span></h6>
                    <h6>Muscle Soreness: <span class="badge bg-warning">Moderate</span></h6>
                    <h6>Recovery Activities:</h6>
                    <ul class="list-group">
                        <li class="list-group-item">✓ Morning Stretch</li>
                        <li class="list-group-item">✓ Ice Bath</li>
                        <li class="list-group-item">□ Evening Massage</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Performance Metrics -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header bg-warning text-dark">
                    <h5><i class="fas fa-chart-line"></i> Performance Metrics</h5>
                </div>
                <div class="card-body">
                    <canvas id="performanceChart"></canvas>
                    <div class="mt-3">
                        <div class="row">
                            <div class="col-6">
                                <h6>Current Speed: <span class="text-success">32 km/h</span></h6>
                                <h6>Power Output: <span class="text-success">350W</span></h6>
                            </div>
                            <div class="col-6">
                                <h6>Heart Rate: <span class="text-warning">145 bpm</span></h6>
                                <h6>VO2 Max: <span class="text-success">58.5</span></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const trainingLoadCtx = document.getElementById('trainingLoadChart').getContext('2d');
    const trainingLoadChart = new Chart(trainingLoadCtx, {
        type: 'line',
        data: {
            labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
            datasets: [{ label: 'Load', data: [300,400,350,420,390,400,410], borderColor: 'blue', tension: 0.3 }]
        }
    });

    const performanceCtx = document.getElementById('performanceChart').getContext('2d');
    const performanceChart = new Chart(performanceCtx, {
        type: 'bar',
        data: {
            labels: ['Speed','Power','Heart Rate','VO2 Max'],
            datasets: [{ label: 'Metrics', data: [32,350,145,58.5], backgroundColor: ['green','orange','red','blue'] }]
        }
    });
</script>
</body>
</html>
