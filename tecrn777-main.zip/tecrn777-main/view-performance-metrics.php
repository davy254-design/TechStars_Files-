<?php
session_start();

// Only Coach can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coach') {
    header("Location: signin.php");
    exit();
}

$athleteName = $_GET['athlete'] ?? 'Unknown Athlete';

// Example: Fetch athlete performance from database
$performanceData = [
    'speed' => [30, 32, 31, 33, 34],
    'power' => [320, 340, 350, 330, 360],
    'heart_rate' => [140, 145, 142, 148, 150]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performance Metrics - <?php echo htmlspecialchars($athleteName); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2>Performance Metrics for <?php echo htmlspecialchars($athleteName); ?></h2>

    <canvas id="speedChart" height="100"></canvas>
    <canvas id="powerChart" height="100" class="mt-4"></canvas>
    <canvas id="hrChart" height="100" class="mt-4"></canvas>

    <a href="coach-dashboard.php" class="btn btn-secondary mt-4">Back</a>
</div>

<script>
    const speedCtx = document.getElementById('speedChart').getContext('2d');
    new Chart(speedCtx, {
        type: 'line',
        data: {
            labels: ['Day1','Day2','Day3','Day4','Day5'],
            datasets: [{
                label: 'Speed (km/h)',
                data: <?php echo json_encode($performanceData['speed']); ?>,
                borderColor: 'blue',
                fill: false
            }]
        }
    });

    const powerCtx = document.getElementById('powerChart').getContext('2d');
    new Chart(powerCtx, {
        type: 'line',
        data: {
            labels: ['Day1','Day2','Day3','Day4','Day5'],
            datasets: [{
                label: 'Power (W)',
                data: <?php echo json_encode($performanceData['power']); ?>,
                borderColor: 'green',
                fill: false
            }]
        }
    });

    const hrCtx = document.getElementById('hrChart').getContext('2d');
    new Chart(hrCtx, {
        type: 'line',
        data: {
            labels: ['Day1','Day2','Day3','Day4','Day5'],
            datasets: [{
                label: 'Heart Rate (bpm)',
                data: <?php echo json_encode($performanceData['heart_rate']); ?>,
                borderColor: 'red',
                fill: false
            }]
        }
    });
</script>
</body>
</html>
