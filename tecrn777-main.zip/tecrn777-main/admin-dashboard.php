<?php
session_start();

// Check if user is logged in and role is Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: signin.php");
    exit();
}

// Admin name
$adminName = $_SESSION['fullname'] ?? 'Admin';

// Connect to database (update credentials as needed)
$conn = new mysqli('localhost', 'root', '', 'athlete');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all users
$sql = "SELECT id, fullname, email, role FROM users";
$result = $conn->query($sql);
$users = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container-fluid">
    <nav class="navbar navbar-dark bg-danger mb-4">
        <div class="container">
            <span class="navbar-brand mb-0 h1">Admin Dashboard</span>
            <span class="text-white">Welcome, <?php echo htmlspecialchars($adminName); ?></span>
        </div>
    </nav>

    <div class="row">
        <!-- User Management Section -->
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fas fa-users-cog"></i> Manage System Users</h5>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['fullname']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['role']); ?></td>
                                <td>
                                    <?php echo $user['status'] === 'verified' ? '<span class="badge bg-success">Verified</span>' : '<span class="badge bg-warning text-dark">Pending</span>'; ?>
                                </td>
                                <td>
                                    <?php if($user['status'] !== 'verified'): ?>
                                        <a href="verify_user.php?id=<?php echo $user['id']; ?>" class="btn btn-success btn-sm">
                                            <i class="fas fa-check"></i> Verify
                                        </a>
                                    <?php endif; ?>
                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?');">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($users)): ?>
                                <tr><td colspan="5" class="text-center">No users found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <a href="register.html" class="btn btn-primary"><i class="fas fa-plus"></i> Add New User</a>
                </div>
            </div>
        </div>

        <!-- System Overview Section -->
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5><i class="fas fa-chart-line"></i> System Overview</h5>
                </div>
                <div class="card-body">
                    <p>Total Users: <?php echo count($users); ?></p>
                    <p>Pending Verifications: <?php echo count(array_filter($users, fn($u) => $u['status'] !== 'verified')); ?></p>
                    <p>Other system statistics can be added here (e.g., total athletes, coaches, etc.)</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
