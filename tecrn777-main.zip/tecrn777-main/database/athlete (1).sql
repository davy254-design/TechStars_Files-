-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2025 at 06:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `athlete`
--

-- --------------------------------------------------------

--
-- Table structure for table `nutrition_plans`
--

CREATE TABLE `nutrition_plans` (
  `id` int(11) NOT NULL,
  `athlete_id` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `plan_name` varchar(255) NOT NULL,
  `plan_details` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `performance_metrics`
--

CREATE TABLE `performance_metrics` (
  `id` int(11) NOT NULL,
  `athlete_id` int(11) NOT NULL,
  `metric_date` date NOT NULL,
  `speed` float DEFAULT NULL,
  `power` float DEFAULT NULL,
  `heart_rate` float DEFAULT NULL,
  `vo2_max` float DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `training_plans`
--

CREATE TABLE `training_plans` (
  `id` int(11) NOT NULL,
  `athlete_id` int(11) NOT NULL,
  `coach_id` int(11) NOT NULL,
  `plan_name` varchar(255) NOT NULL,
  `plan_details` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Coach','Athlete','Admin','Nutritionist') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `weekly_load` int(11) DEFAULT NULL,
  `chronic_ratio` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `role`, `created_at`, `weekly_load`, `chronic_ratio`) VALUES
(1, 'David Ochieng', 'admin123@gmail.com', '$2y$10$dsLieh147TCgh9fy.YXHnu/3ppZPDHOlg7KJAE0RmYak.IRLCWTD6', 'Athlete', '2025-11-10 01:03:47', NULL, NULL),
(2, 'David Ochieng', 'daudi123@gmail.com', '$2y$10$buhTmidofUz2A6zWjFktCeQEjIEJfQqPyOkMu4Qev3qjIra0Hzy3W', 'Athlete', '2025-11-10 01:10:10', NULL, NULL),
(3, 'Jevan Kiptum', 'kiptum123@gmail.com', '$2y$10$m3pZJSne3kGu91hPCF46b.GSviVNyY14Z2YZgN16UGo72i5OM0.AO', 'Coach', '2025-11-10 02:04:57', NULL, NULL),
(4, 'George Kipruto', 'kipruto123@gmail.com', '$2y$10$q.kNsf2SitwG/fuyMPuGCeGW54eHXnDZqw3itZUHIrLmJ8IzsvP3S', 'Admin', '2025-11-10 02:18:53', NULL, NULL),
(5, 'Jevan Kiptum', 'daudi1234@gmail.com', '$2y$10$T5sH9MvOlAxPNv81MdKUpeMTHkYcT.8vTZpgh4VMgtksCW2Ad4TvS', 'Coach', '2025-11-10 02:32:31', NULL, NULL),
(6, 'Eunice Cheptoo', 'cheptoo123@gmail.com', '$2y$10$EwGfRBqz7c2rXTLhVtQ2OevY2cocypreJnr/WjL7SgpK29YW3kXiq', 'Athlete', '2025-11-10 02:50:33', NULL, NULL),
(7, 'Mathews Kipng\'eno', 'daudi1237@gmail.com', '$2y$10$njwE0fgsrRL2oD0Y9dNIWepJu0F10TD6hI9G8sVlJ7btnThOVxGEu', 'Admin', '2025-11-10 02:55:52', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `nutrition_plans`
--
ALTER TABLE `nutrition_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `performance_metrics`
--
ALTER TABLE `performance_metrics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `training_plans`
--
ALTER TABLE `training_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `nutrition_plans`
--
ALTER TABLE `nutrition_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `performance_metrics`
--
ALTER TABLE `performance_metrics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `training_plans`
--
ALTER TABLE `training_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
